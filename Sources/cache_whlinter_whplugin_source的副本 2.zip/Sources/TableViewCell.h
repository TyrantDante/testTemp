//
//  TableViewCell.h
//  funnyrunner
//
//  Created by 戴易超 on 2019/5/29.
//  Copyright © 2019 戴易超. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
