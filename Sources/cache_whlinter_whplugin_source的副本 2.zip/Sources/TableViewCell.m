//
//  TableViewCell.m
//  funnyrunner
//
//  Created by 戴易超 on 2019/5/29.
//  Copyright © 2019 戴易超. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
